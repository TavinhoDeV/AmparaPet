package br.com.ampara.dao;

import br.com.ampara.model.Usuario;
import java.util.Optional;

public interface UsuarioDAO {

    Optional<Usuario> buscarPorEmail(String email);

    Usuario salvar(Usuario usuario);
}
