package br.com.ampara.service;

import br.com.ampara.exception.RegraNegocioException;
import br.com.ampara.model.Animal;
import br.com.ampara.model.StatusAnimal;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Regras do processo de adoção. A decisão nunca depende apenas da interface:
 * toda adoção deve passar por este serviço.
 */
@ApplicationScoped
public class AdocaoService {

    /** Garante que o animal cumpriu todas as etapas obrigatórias antes da adoção. */
    public void validarAdocao(Animal animal) {
        if (animal == null) {
            throw new RegraNegocioException("Animal não informado.");
        }
        if (!animal.isVacinado()) {
            throw new RegraNegocioException("Adoção não permitida: a vacinação ainda não foi validada.");
        }
        if (!animal.isCastrado()) {
            throw new RegraNegocioException("Adoção não permitida: a castração ainda não foi validada.");
        }
        if (animal.getStatus() == StatusAnimal.ADOTADO) {
            throw new RegraNegocioException("Este animal já foi adotado.");
        }
        if (animal.getStatus() != StatusAnimal.APTO_ADOCAO) {
            throw new RegraNegocioException("Adoção não permitida: o animal ainda não está apto para adoção.");
        }
    }

    public void adotar(Animal animal) {
        validarAdocao(animal);
        animal.setStatus(StatusAnimal.ADOTADO);
    }
}
