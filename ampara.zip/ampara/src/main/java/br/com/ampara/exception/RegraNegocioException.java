package br.com.ampara.exception;

/** Violação de uma regra de negócio do Ampara. A mensagem é exibível ao usuário. */
public class RegraNegocioException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public RegraNegocioException(String mensagem) {
        super(mensagem);
    }
}
