package br.com.ampara.model;

/** Etapas padronizadas do ciclo de atendimento de um animal. */
public enum StatusAnimal {
    RESGATADO("Resgatado"),
    EM_TRIAGEM("Em triagem"),
    EM_TRATAMENTO("Em tratamento"),
    APTO_ADOCAO("Apto para adoção"),
    ADOTADO("Adotado");

    private final String descricao;

    StatusAnimal(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }
}
