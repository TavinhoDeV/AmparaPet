package br.com.ampara.controller;

import br.com.ampara.model.Usuario;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.context.ExternalContext;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import jakarta.servlet.http.HttpServletRequest;
import java.io.Serializable;

/** Guarda o usuário autenticado durante a sessão HTTP. */
@Named
@SessionScoped
public class SessaoController implements Serializable {

    private static final long serialVersionUID = 1L;

    private Usuario usuarioLogado;

    public boolean isAutenticado() {
        return usuarioLogado != null;
    }

    public Usuario getUsuarioLogado() {
        return usuarioLogado;
    }

    public void iniciar(Usuario usuario) {
        // Gera novo identificador de sessão após o login (previne session fixation).
        ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
        ((HttpServletRequest) ec.getRequest()).changeSessionId();
        this.usuarioLogado = usuario;
    }

    public String sair() {
        this.usuarioLogado = null;
        FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
        return "/login.xhtml?faces-redirect=true";
    }
}
