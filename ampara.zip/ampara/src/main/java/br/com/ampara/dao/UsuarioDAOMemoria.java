package br.com.ampara.dao;

import br.com.ampara.model.Perfil;
import br.com.ampara.model.Usuario;
import br.com.ampara.util.SenhaUtil;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Implementação temporária em memória, usada até a camada de persistência
 * relacional ser concluída. Substituir por uma implementação JPA/JDBC.
 */
@ApplicationScoped
public class UsuarioDAOMemoria implements UsuarioDAO {

    private final Map<String, Usuario> porEmail = new ConcurrentHashMap<>();
    private final AtomicLong sequencia = new AtomicLong();

    @PostConstruct
    void carregarDadosDeDemonstracao() {
        salvar(new Usuario(null, "Administração Ampara", "admin@ampara.org",
                SenhaUtil.gerarHash("Ampara@123"), Perfil.ADMINISTRACAO));
        salvar(new Usuario(null, "Voluntária Demo", "voluntario@ampara.org",
                SenhaUtil.gerarHash("Ampara@123"), Perfil.VOLUNTARIO));
    }

    @Override
    public Optional<Usuario> buscarPorEmail(String email) {
        return Optional.ofNullable(email).map(e -> porEmail.get(e.trim().toLowerCase()));
    }

    @Override
    public Usuario salvar(Usuario usuario) {
        if (usuario.getId() == null) {
            usuario.setId(sequencia.incrementAndGet());
        }
        porEmail.put(usuario.getEmail().trim().toLowerCase(), usuario);
        return usuario;
    }
}
