package br.com.ampara.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import br.com.ampara.exception.RegraNegocioException;
import br.com.ampara.model.Animal;
import br.com.ampara.model.StatusAnimal;
import org.junit.jupiter.api.Test;

class AdocaoServiceTest {

    private final AdocaoService service = new AdocaoService();

    private Animal animal(boolean vacinado, boolean castrado, StatusAnimal status) {
        Animal a = new Animal(1L, "Caramelo", "Cão");
        a.setVacinado(vacinado);
        a.setCastrado(castrado);
        a.setStatus(status);
        return a;
    }

    @Test
    void bloqueiaAdocaoSemVacinacao() {
        assertThrows(RegraNegocioException.class,
                () -> service.validarAdocao(animal(false, true, StatusAnimal.APTO_ADOCAO)));
    }

    @Test
    void bloqueiaAdocaoSemCastracao() {
        assertThrows(RegraNegocioException.class,
                () -> service.validarAdocao(animal(true, false, StatusAnimal.APTO_ADOCAO)));
    }

    @Test
    void bloqueiaAdocaoForaDaEtapaCorreta() {
        assertThrows(RegraNegocioException.class,
                () -> service.validarAdocao(animal(true, true, StatusAnimal.EM_TRATAMENTO)));
    }

    @Test
    void permiteAdocaoQuandoTudoValidado() {
        Animal a = animal(true, true, StatusAnimal.APTO_ADOCAO);
        assertDoesNotThrow(() -> service.adotar(a));
        assertEquals(StatusAnimal.ADOTADO, a.getStatus());
    }
}
