package br.com.ampara.filter;

import br.com.ampara.controller.SessaoController;
import jakarta.inject.Inject;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/** Bloqueia o acesso às páginas internas por usuários não autenticados. */
@WebFilter(urlPatterns = {"/painel.xhtml"})
public class AutenticacaoFilter implements Filter {

    @Inject
    private SessaoController sessao;

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;

        if (sessao.isAutenticado()) {
            response.setHeader("Cache-Control", "no-store");
            chain.doFilter(req, res);
        } else {
            response.sendRedirect(request.getContextPath() + "/login.xhtml");
        }
    }
}
