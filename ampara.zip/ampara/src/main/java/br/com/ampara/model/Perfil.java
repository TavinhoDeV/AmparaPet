package br.com.ampara.model;

/** Perfis de acesso previstos na plataforma. */
public enum Perfil {
    VOLUNTARIO("Voluntário"),
    CLINICA_INSTITUICAO("Clínica / Instituição"),
    ADMINISTRACAO("Administração");

    private final String descricao;

    Perfil(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }
}
