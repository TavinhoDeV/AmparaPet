# AMPARA
**Sistema de Triagem e Acolhimento de Animais Urbanos**

Plataforma web para centralizar o resgate, a triagem, o tratamento e a adoção de animais em situação de rua, com histórico rastreável de cada animal.

## Estado atual
- Java 25 + Maven, execução local no WildFly 41
- Jakarta Faces + PrimeFaces 15 + PrimeIcons
- Tela de login responsiva, com validações e mensagens personalizadas
- Campo de senha com exibir/ocultar
- Recuperação de senha, acesso institucional e cadastro preparados na interface
- Autenticação com senha protegida por PBKDF2 (DAO em memória, temporário)
- Regra de adoção na camada de serviço (vacinação e castração obrigatórias), com testes unitários

## Estrutura
```
src/main/java/br/com/ampara/
├── controller/   Beans da interface (login, sessão)
├── model/        Entidades e enums
├── service/      Regras de negócio
├── dao/          Acesso a dados (interfaces + implementação em memória)
├── filter/       Proteção de páginas internas
├── exception/    Exceções de negócio
└── util/         Utilitários (hash de senha)
src/main/webapp/  login.xhtml, painel.xhtml, resources/ (css, imagens)
```

## Executando
Pré-requisitos: JDK 25, Maven e WildFly 41.

```bash
java -version
mvn -version
mvn clean wildfly:dev
```
Acesse: http://localhost:8080/ampara-1.0-SNAPSHOT/login.xhtml

Nova publicação sem reiniciar o servidor: `mvn wildfly:redeploy`  
Testes: `mvn test`

### Usuários de demonstração (temporários)
| E-mail | Senha | Perfil |
|---|---|---|
| admin@ampara.org | Ampara@123 | Administração |
| voluntario@ampara.org | Ampara@123 | Voluntário |

> Remover quando a persistência em banco estiver pronta.

## Próximas etapas
Cadastro de usuários e recuperação de senha, entidades de animal/resgate/triagem, DAOs com banco relacional, perfis e permissões, painel administrativo.

## Contexto
Projeto acadêmico de Análise e Desenvolvimento de Sistemas, ligado a Cidades Inteligentes e Saúde Única.
