package br.com.ampara.service;

import br.com.ampara.dao.UsuarioDAO;
import br.com.ampara.exception.RegraNegocioException;
import br.com.ampara.model.Usuario;
import br.com.ampara.util.SenhaUtil;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class AutenticacaoService {

    private static final String CREDENCIAIS_INVALIDAS = "E-mail ou senha incorretos. Confira os dados e tente novamente.";

    @Inject
    private UsuarioDAO usuarioDAO;

    public Usuario autenticar(String email, String senha) {
        Usuario usuario = usuarioDAO.buscarPorEmail(email)
                .orElseThrow(() -> new RegraNegocioException(CREDENCIAIS_INVALIDAS));

        if (!SenhaUtil.verificar(senha, usuario.getSenhaHash())) {
            throw new RegraNegocioException(CREDENCIAIS_INVALIDAS);
        }
        return usuario;
    }
}
