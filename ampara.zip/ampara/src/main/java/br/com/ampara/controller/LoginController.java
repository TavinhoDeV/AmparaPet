package br.com.ampara.controller;

import br.com.ampara.exception.RegraNegocioException;
import br.com.ampara.model.Usuario;
import br.com.ampara.service.AutenticacaoService;
import jakarta.enterprise.context.RequestScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Inject;
import jakarta.inject.Named;

@Named
@RequestScoped
public class LoginController {

    @Inject
    private AutenticacaoService autenticacaoService;

    @Inject
    private SessaoController sessao;

    private String email;
    private String senha;

    public String entrar() {
        try {
            Usuario usuario = autenticacaoService.autenticar(email, senha);
            sessao.iniciar(usuario);
            return "/painel.xhtml?faces-redirect=true";
        } catch (RegraNegocioException e) {
            mensagem(FacesMessage.SEVERITY_ERROR, "Não foi possível entrar", e.getMessage());
            return null;
        }
    }

    public void recuperarSenha() {
        mensagem(FacesMessage.SEVERITY_INFO, "Recuperação de senha",
                "Este recurso estará disponível em breve.");
    }

    public void acessoInstitucional() {
        mensagem(FacesMessage.SEVERITY_INFO, "Acesso institucional",
                "O acesso para clínicas e instituições estará disponível em breve.");
    }

    public void cadastrar() {
        mensagem(FacesMessage.SEVERITY_INFO, "Novo cadastro",
                "O cadastro de novos usuários estará disponível em breve.");
    }

    private void mensagem(FacesMessage.Severity tipo, String titulo, String detalhe) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(tipo, titulo, detalhe));
    }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }
}
