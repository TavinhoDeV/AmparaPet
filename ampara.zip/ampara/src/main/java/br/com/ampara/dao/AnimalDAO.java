package br.com.ampara.dao;

import br.com.ampara.model.Animal;
import java.util.List;
import java.util.Optional;

/** Contrato de acesso a dados de animais. A implementação virá com o banco relacional. */
public interface AnimalDAO {

    Optional<Animal> buscarPorId(Long id);

    List<Animal> listarTodos();

    Animal salvar(Animal animal);
}
